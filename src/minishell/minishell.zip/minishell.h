#ifndef _minishell_H_
#define _minishell_H_

#include "../../include/my.h"
#include "sys/wait.h"

int main(int argc, char** argv);

#endif